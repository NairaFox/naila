# 奈拉计算器 Web App

这是一个简单的汇率换算器，基于 HTML/CSS/JavaScript 编写。

## 部署到 GitHub Pages

1. 将此仓库上传到你的 GitHub 账号
2. 打开仓库 Settings → Pages
3. 选择 main 分支，并设置为根目录（/root）
4. 等待几秒，你将获得一个访问链接，例如：
   https://your-username.github.io/naira-calculator/

## 功能说明

- 输入奈拉汇率、手续费、利润率等
- 实时计算“元”和“奈拉”的收入、成本和利润
